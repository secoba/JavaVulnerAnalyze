package seeyon;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class SeeyonServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        iMsgServer2000 msg = new iMsgServer2000();
        byte[] buf = msg.ReadPackage(req);
        System.out.println(msg.GetMsgByName("RECORDID"));
        System.out.println(msg.GetMsgByName("FILENAME"));
        System.out.println(msg.GetFieldText());
        System.out.println(msg.GetFieldValue(0));
        System.out.println("----------------------------");
        for (int i = 0; i < msg.GetFieldCount(); i++) {
            System.out.println(msg.GetFieldName(i) + " <===> " + msg.GetFieldValue(i));
        }
        System.out.println("----------------------------");
        PrintWriter out = resp.getWriter();
        out.println(new String(buf) + "\n----------------------------\n" + msg.GetMsgByName("FILENAME"));
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
